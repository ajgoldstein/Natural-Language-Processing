'''
Sulaimon Lasisi slasisi@umich.edu
'''
import os, argparse, math, operator
import pdb
import time

parser = argparse.ArgumentParser(description='Receives input for train file')
parser.add_argument('train_file', help='file containing strings to be used to train')
args = parser.parse_args()





#stop_words_list generated using spacy. This will improve context probability
#because all the common words are eliminated

stop_words_list = ['a', 'about', 'above', 'across', 'after', 'afterwards', 'again', 'against', 'all', 'almost', 'alone', 'along', 'already', 'also', 'although', 'always', 'am', 'among', 'amongst', 'amount', 'an', 'and', 'another', 'any', 'anyhow', 'anyone', 'anything', 'anyway', 'anywhere', 'are', 'around', 'as', 'at', 'back', 'be', 'became', 'because', 'become', 'becomes', 'becoming', 'been', 'before', 'beforehand', 'behind', 'being', 'below', 'beside', 'besides', 'between', 'beyond', 'both', 'bottom', 'but', 'by', 'call', 'can', 'cannot', 'ca', 'could', 'did', 'do', 'does', 'doing', 'done', 'down', 'due', 'during', 'each', 'eight', 'either', 'eleven', 'else', 'elsewhere', 'empty', 'enough', 'etc', 'even', 'ever', 'every', 'everyone', 'everything', 'everywhere', 'except', 'few', 'fifteen', 'fifty', 'first', 'five', 'for', 'former', 'formerly', 'forty', 'four', 'from', 'front', 'full', 'further', 'get', 'give', 'go', 'had', 'has', 'have', 'he', 'hence', 'her', 'here', 'hereafter', 'hereby', 'herein', 'hereupon', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'however', 'hundred', 'i', 'if', 'in', 'inc', 'indeed', 'into', 'is', 'it', 'its', 'itself', 'keep', 'last', 'latter', 'latterly', 'least', 'less', 'just', 'made', 'make', 'many', 'may', 'me', 'meanwhile', 'might', 'mine', 'more', 'moreover', 'most', 'mostly', 'move', 'much', 'must', 'my', 'myself', 'name', 'namely', 'neither', 'never', 'nevertheless', 'next', 'nine', 'no', 'nobody', 'none', 'noone', 'nor', 'not', 'nothing', 'now', 'nowhere', 'of', 'off', 'often', 'on', 'once', 'one', 'only', 'onto', 'or', 'other', 'others', 'otherwise', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'part', 'per', 'perhaps', 'please', 'put', 'quite', 'rather', 're', 'really', 'regarding', 'same', 'say', 'see', 'seem', 'seemed', 'seeming', 'seems', 'serious', 'several', 'she', 'should', 'show', 'side', 'since', 'six', 'sixty', 'so', 'some', 'somehow', 'someone', 'something', 'sometime', 'sometimes', 'somewhere', 'still', 'such', 'take', 'ten', 'than', 'that', 'the', 'their', 'them', 'themselves', 'then', 'thence', 'there', 'thereafter', 'thereby', 'therefore', 'therein', 'thereupon', 'these', 'they', 'third', 'this', 'those', 'though', 'three', 'through', 'throughout', 'thru', 'thus', 'to', 'together', 'too', 'top', 'toward', 'towards', 'twelve', 'twenty', 'two', 'under', 'until', 'up', 'unless', 'upon', 'us', 'used', 'using', 'various', 'very', 'very', 'via', 'was', 'we', 'well', 'were', 'what', 'whatever', 'when', 'whence', 'whenever', 'where', 'whereafter', 'whereas', 'whereby', 'wherein', 'whereupon', 'wherever', 'whether', 'which', 'while', 'whither', 'who', 'whoever', 'whole', 'whom', 'whose', 'why', 'will', 'with', 'within', 'without', 'would', 'yet', 'you', 'your', 'yours', 'yourself', 'yourselves', 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred', 'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'gajillion', 'bazillion', 'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eigth', 'ninth', 'tenth', 'eleventh', 'twelveth', 'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth', 'sventeenth', 'eighteenth', 'nineteenth', 'twentieth', '', 'thirtieth', 'fortieth', 'fiftieth', 'sixtieth', 'seventieth', 'eightieth', 'ninetieth', 'hundreth', 'thousandth', 'millionth', 'billionth', 'trillionth', 'quadrillionth', 'gajillionth', 'bazillionth']



def get_instance_count(file):
  instance_count = 0
  with open(file) as f:
    for line in f:
      if line.find("<instance") > -1:
        instance_count +=1
  return instance_count
def noun_wsd(file):
  #Divide file into five folds
  
  num_folds = 5
  instance_count = get_instance_count(file)
  #print("Instance count", instance_count)
  total_accuracy = 0.0
  for fold_ctr in range(0, num_folds):
    print("Fold", (fold_ctr+1))
    total_accuracy += parse_word_sense( file, fold_ctr, num_folds)
  print("Average accuracy", float(total_accuracy)/num_folds)

def parse_word_sense(file, fold, num_folds):
  noun_not_found = True
  noun = ''
  strip_list = ['.', '(', ')', ',', '-']
  training_sense_dict_count = {}
  training_features_sense_dict_count = {}
  with open(file) as f:
    instance_count = 0
    for line in f:
      if line.find("<instance") > -1:
        id = line.split(" ")[1].split("=")[1].strip("\"")
        if noun_not_found:
          noun = id.split('.')[0]
          noun_not_found = False
        sense = next(f).split(" ")[2].split('%')[1].strip("\"/>\n")      
        if instance_count%num_folds != fold:        
          if sense not in training_sense_dict_count:
            training_sense_dict_count[sense] = 1.0
            training_features_sense_dict_count[sense] = {}
          else:
            training_sense_dict_count[sense] += 1.0
          context_start = next(f)
          features_line = next(f).strip('. \n').split(" ")
          for word in features_line:
            for strip_item in strip_list:
              word = word.strip(strip_item)
            word = word.lower().strip()
            if word.find("<head>") == -1 and word not in stop_words_list:
              if word not in training_features_sense_dict_count[sense]:
                training_features_sense_dict_count[sense][word] = 1.0
              #else:
              #  training_features_sense_dict_count[sense][word] += 1
        else:
          next(f)
          next(f)
        context_end = next(f)
        instance_close_line = next(f)
        empty_line = next(f)
        instance_count +=1

  #get sum of both senses occuring in training set
  sense_count_sum = 0
  for sense in training_sense_dict_count:
    sense_count_sum += training_sense_dict_count[sense]
    #print(sense, training_sense_dict_count[sense])
  
  #write test output to file
  wsd_fname = noun+".wsd.out"
  #print(wsd_fname)
  fw=open(wsd_fname, "a+")
  fold_header = 'Fold '+str(fold+1)+'\n'
  fw.write(fold_header)

  #get sentences in test_fold
  with open(file) as test_f:
    test_count = 0
    correct_count = 0
    instance_count = 0
    for line in test_f:
      if line.find("<instance") > -1:
        id = line.split(" ")[1].split("=")[1].strip("\"")
        true_sense = next(test_f).split(" ")[2].split('%')[1].strip("\"/>\n")
        if instance_count%num_folds == fold:
          test_count +=1                  
          context_start = next(test_f)
          features_line = next(test_f).strip('. \n').split(" ")
          for word in features_line:
            for strip_item in strip_list:
              word = word.strip(strip_item)
            word = word.lower().strip()
            if word.find("<head>") == -1 and word not in stop_words_list:
              for sense in training_sense_dict_count:
                if word not in training_features_sense_dict_count[sense]:                  
                  training_features_sense_dict_count[sense][word] = 0.0
          #add-one smoothing
          for sense in training_sense_dict_count:
            for word in training_features_sense_dict_count[sense]:
              training_features_sense_dict_count[sense][word] += 0.01
          #argmax calculation
          max_sense = {}
          for sense in training_sense_dict_count:
            max_sense[sense] = 1.0
            for word in features_line:
              for strip_item in strip_list:
                word = word.strip(strip_item)
              word = word.lower().strip()
              if word.find("<head>") == -1 and word not in stop_words_list:
                max_sense[sense] = max_sense[sense] * float(training_features_sense_dict_count[sense][word])/training_sense_dict_count[sense]
            max_sense[sense] = max_sense[sense] * (float(training_sense_dict_count[sense] )/ sense_count_sum)
            print(sense, max_sense[sense])
          max_sense = max(max_sense.items(), key=operator.itemgetter(1))[0]
          #max_sense = max(max_sense.iteritems(), key=operator.itemgetter(1))[0]
          if max_sense == true_sense:
            correct_count +=1
          noun_tag = id.split('.')[0]+'%'+max_sense
          file_entry = id+' '+noun_tag+'\n'
          fw.write(file_entry)
          #print(id, noun_tag)  -- should be printed in file
        else:
          next(test_f)
          next(test_f)
        context_end = next(test_f)
        instance_close_line = next(test_f)
        empty_line = next(test_f)
        instance_count +=1
    accuracy = round((float(correct_count)/test_count)*100,2)
    print("Accuracy:", accuracy, "percent")
  fw.close()

  #print("LIVING DICTIONARY" + '\n' + '\n')
  #print(training_features_sense_dict_count['living'])
  #print("FACTORY DICTIONARY" + '\n' + '\n')
  #print(training_features_sense_dict_count['factory'])

  return accuracy
        
noun_wsd(args.train_file)