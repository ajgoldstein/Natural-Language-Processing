
# # EECS 498 - Assignment 1 - Collocations.py

# ### 1) Read in and process data

from __future__ import division
import string
import math
import numpy as np
import sys
import operator

# 1) Read in and process data

def read_in_and_process_data(input_file):

    # create lists for storage
    unigram_dict = {}
    bigram_dict = {}
    prev_word = "."

    # read in file line-by-line, word-by-word
    with open(input_file) as f:
        for line in f:
            splitLine = line.split()
            for word in splitLine:
                
                # store unigram (no tokens of only punctuation)
                if word not in string.punctuation:
                    if word in unigram_dict:
                        unigram_dict[word] += 1
                    else:
                        unigram_dict[word] = 1
                
                    # store bigram (no tokens of only punctuation)
                    if prev_word not in string.punctuation:
                        bigram = prev_word + ' ' + word
                        if bigram in bigram_dict:
                            bigram_dict[bigram] += 1
                        else:
                            bigram_dict[bigram] = 1
                
                # set new prev_word
                prev_word = word
                
    # discard bigrams that occur less than 5 times
    bigram_dict = { bigram:count for bigram, count in bigram_dict.items() if count >=5 }

    # return unigram and bigram dictionaries
    return unigram_dict, bigram_dict



# 2) Create bigram confusion matrices

def create_confusion_matrices(bigram_dict):

    # #### Step 1: Loop through bigrams, save 1st/2nd word counts in dictionaries

    # create dictionaries with "key-value" pairs of "word-count"
    first_word_dict = {}
    second_word_dict = {}

    # loop through every bigram in the dictionary
    for bigram,value in bigram_dict.items():
        
        # extract each bigram, word1, & word2
        word1 = bigram.split()[0]
        word2 = bigram.split()[1]
        
        # store first words
        if word1 in first_word_dict:
            first_word_dict[word1] += 1
        else:
            first_word_dict[word1] = 1
        
        # store second words
        if word2 in second_word_dict:
            second_word_dict[word2] += 1
        else:
            second_word_dict[word2] = 1


    # #### Step 2: Retrieve and store confusion matrix counts for each bigram

    # create dictionary with "key-value" pairs of "bigram-matrix(list)"
    confusion_matrices = {}

    for bigram,value in bigram_dict.items():
        
        # extract each word1 & word2
        word1 = bigram.split()[0]
        word2 = bigram.split()[1]
        
        # calculate values for confusion matrix
        bigramCount = bigram_dict[bigram] # 1st value: bigram occurences
        secondWordCount = second_word_dict[word2] - bigram_dict[bigram] # 2nd value: word2 occurences (non-bigram)
        firstWordCount = first_word_dict[word1]-bigram_dict[bigram] # 3rd value: word1 occurences (non-bigram)
        neitherCount = len(bigram_dict) - bigramCount - secondWordCount - firstWordCount # 4th value: non word1 or word2
        
        # store values as confusion matrix
        matrix = [bigramCount, secondWordCount, firstWordCount, neitherCount]
        confusion_matrices[bigram] = matrix


    return confusion_matrices, first_word_dict, second_word_dict



# ### 3) Calculate Chi-Square stat for each bigram

def calculate_chi_square(confusion_matrices):

    # create dictionary with "key-value" pairs of "bigram-chiSquare"
    chi_square_stats = {}

    for bigram, matrix in confusion_matrices.items():
        
        # save observed values
        ob11 = matrix[0]
        ob12 = matrix[1]
        ob21 = matrix[2]
        ob22 = matrix[3]
        
        # save col/row total values
        totC1 = ob11 + ob21
        totC2 = ob12 + ob22
        totR1 = ob11 + ob12
        totR2 = ob21 + ob22
        total = ob11 + ob12 + ob21 + ob22
        
        # calculate expected values
        ex11 = (totR1*totC1)/total
        ex12 = (totR1*totC2)/total
        ex21 = (totR2*totC1)/total
        ex22 = (totR2*totC2)/total
        
        # calculate chi_squared statistic
        chi11 = pow((ob11-ex11),2)/ex11
        chi12 = pow((ob12-ex12),2)/ex12
        chi21 = pow((ob21-ex21),2)/ex21
        chi22 = pow((ob22-ex22),2)/ex22
        chi_square = chi11 + chi12 + chi21 + chi22
        
        # store statistic in dictionary with bigram as key
        chi_square_stats[bigram] = chi_square

    return chi_square_stats

# ### 4) Calculate PMI stat for each bigram

def calculate_PMI(confusion_matrices, bigram_dict, first_word_dict, second_word_dict):

    # create dictionary with "key-value" pairs of "bigram-PMI"
    PMI_stats = {}

    for bigram,matrix in confusion_matrices.items():
        
        # split bigram into words
        word1 = bigram.split()[0]
        word2 = bigram.split()[1]
        
        # calculate probability values
        prob_bigram = bigram_dict[bigram]/len(bigram_dict)
        prob_word1 = first_word_dict[word1]/len(first_word_dict)
        prob_word2 = second_word_dict[word2]/len(second_word_dict)
        
        # calculate PMI statistic
        PMI = math.log(prob_bigram/(prob_word1*prob_word2))
        
        # store statistic in dictionary with bigram as key
        PMI_stats[bigram] = PMI

    return PMI_stats

def main():

    # save input file & measure type
    input_file = sys.argv[1]
    measure_type = sys.argv[2]

    # 1) read in and process data
    unigram_dict, bigram_dict = read_in_and_process_data(input_file)

    # 2) create bigram confusion matrices
    confusion_matrices, first_word_dict, second_word_dict = create_confusion_matrices(bigram_dict)

    # 3) calculate requested measurement values
    if measure_type == "chi-square":
        stats = calculate_chi_square(confusion_matrices)
    if measure_type == "PMI":
        stats = calculate_PMI(confusion_matrices, bigram_dict, first_word_dict, second_word_dict)

    # 4) output top 20 ranked bigrams
    ranked_bigrams = sorted(stats.items(), key=operator.itemgetter(1), reverse = True)
    for bigram in ranked_bigrams[:20]:
        print bigram[0], bigram[1]

if __name__ == "__main__":
    main()




